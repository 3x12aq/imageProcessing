#include "lib/myPng.h"

#define TRUE 1
#define FALSE 0

int rowIsSolidColor(int j, RAWDATA_t raw); // 行が単色ならFALSE
int columnIsSolidColor(int i, RAWDATA_t raw); // 列が単色ならFALSE
int deleteRowsColumns(int *jList, int *iList, RAWDATA_t *raw); // FALSEの行・列を除去する

int main(int argc, char *argv[]) {
  
  RAWDATA_t raw;
  int i, j;
  char outname[256];
  
  if (argc != 2) {
    printf("invalid file name [main] \n");
    return -1;
  }
  
  if (pngFileReadDecode(&raw, argv[1]) == -1) {
    printf("pngFileReadDecode error! [main]\n");
    return -1;
  }
  
  printf("raw->data = %p\n", raw.data);
  printf("raw->width = %d\n", raw.width);
  printf("raw->height = %d\n", raw.height);
  printf("raw->ch = %d\n", raw.ch);
  
  int *jList; // 上端・下端から続いている単色の行をFALSEにする
  jList = (int*)malloc(sizeof(int)*raw.height);
  for (j = 0; j < raw.height; j++) jList[j] = TRUE;
  for (j = 0; j < raw.height; j++) {
    if (rowIsSolidColor(j, raw)) jList[j] = FALSE;
    else break;
  }
  for (j = raw.height - 1; j >= 0; j--) {
    if (rowIsSolidColor(j, raw)) jList[j] = FALSE;
    else break;
  }
  
  int *iList; // 左端・右端から続いている単色の行をFALSEにする
  iList = (int*)malloc(sizeof(int)*raw.width);
  for (i = 0; i < raw.width; i++) iList[i] = TRUE;
  for (i = 0; i < raw.width; i++) {
    if (columnIsSolidColor(i, raw)) iList[i] = FALSE;
    else break;
  }
  for (i = raw.width - 1; i >= 0; i--) {
    if (columnIsSolidColor(i, raw)) iList[i] = FALSE;
    else break;
  }
  
  printf("delete lines row:");
  for (j = 0; j < raw.height; j++) {
    if (!jList[j]) printf(" %d", j);
  }
  printf("\ndelete lines column:");
  for (i = 0; i < raw.width; i++) {
    if (!iList[i]) printf(" %d", i);
  }
  printf("\n");
  
  deleteRowsColumns(jList, iList, &raw);
  free(jList);
  free(iList);
  
  printf("raw->data = %p\n", raw.data);
  printf("raw->width = %d\n", raw.width);
  printf("raw->height = %d\n", raw.height);
  printf("raw->ch = %d\n", raw.ch);
  
  sprintf(outname, "%s", "output.PNG");
  
  if (pngFileEncodeWrite(&raw, outname) == -1) {
    printf("pngFileEncodeWrite error! [main]\n");
    freeRawData(&raw);
    return -1;
  }
  
  freeRawData(&raw);
  
  return 0;
}

int rowIsSolidColor(int j, RAWDATA_t raw) { // FALSE
  int i, c;
  int bufrgb[3];
  int flag;
  i = 0;
  for (c = 0; c < 3; c++) {
    bufrgb[c] = raw.data[raw.ch * (i + j * raw.width) + c];
  }
  flag = TRUE;
  for (i = 1; i < raw.width; i++) {
    for (c = 0; c < 3; c++) {
      if (raw.data[raw.ch * (i + j * raw.width) + c] != bufrgb[c]) {
        flag = FALSE;
        break;
      }
    }
    if (!flag) break;
  }
  return flag;
}

int columnIsSolidColor(int i, RAWDATA_t raw) { // 列が単色ならFALSE
  int j, c;
  int bufrgb[3];
  int flag;
  j = 0;
  for (c = 0; c < 3; c++) {
    bufrgb[c] = raw.data[raw.ch * (i + j * raw.width) + c];
  }
  flag = TRUE;
  for (j = 1; j < raw.height; j++) {
    for (c = 0; c < 3; c++) {
      if (raw.data[raw.ch * (i + j * raw.width) + c] != bufrgb[c]) {
        flag = FALSE;
        break;
      }
    }
    if (!flag) break;
  }
  return flag;
}

int deleteRowsColumns(int *jList, int *iList, RAWDATA_t *pRaw) {
  int i, j, c; // 元の画像の座標
  int ri, rj; // 新しい画像の座標
  
  // 新しい画像の各パラメータ
  unsigned char *data;
  unsigned int width;
  unsigned int height;
  unsigned int ch;
  
  height = 0;
  for (j = 0; j < pRaw->height; j++) if (jList[j]) height++;
  width = 0;
  for (i = 0; i < pRaw->width; i++) if (iList[i]) width++;
  ch = pRaw->ch;
  data = (unsigned char*)malloc(sizeof(unsigned char) * width * height * ch);
  
  rj = 0;  
  for (j = 0; j < pRaw->height; j++) {
    if (jList[j]) { // 単色が続いていた行をスキップ
      ri = 0;
      for (i = 0; i < pRaw->width; i++) {
        if (iList[i]) { // 単色が続いていた列をスキップ
          for (c = 0; c < pRaw->ch; c++) {
            data[ch * (ri + rj * width) + c] = pRaw->data[pRaw->ch * (i + j * pRaw->width) + c];
          }
          ri++;
        }
      }
      rj++;
    }
  }
  free(pRaw->data);
  
  // 新しい画像のパラメータに置き換える
  pRaw->data = data;
  pRaw->width = width;
  pRaw->height = height;
  return 0;
}
